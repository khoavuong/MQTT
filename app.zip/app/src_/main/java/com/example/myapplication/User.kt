package com.example.myapplication

data class User(val id: Int,val name: String = "",
                  val loged_in: Boolean = false)
